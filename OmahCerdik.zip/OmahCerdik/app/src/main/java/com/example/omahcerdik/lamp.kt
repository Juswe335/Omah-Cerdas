package com.example.omahcerdik

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class lamp : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_lamp)

        val lampButton: ImageView = findViewById(R.id.suhu_btn)
        lampButton.setOnClickListener {
            val intent = Intent(this, Suhu::class.java)
            startActivity(intent)
        }

        val lockButton: ImageView = findViewById(R.id.lock_btn)
        lockButton.setOnClickListener {
            val intent = Intent(this, doorlock::class.java)
            startActivity(intent)
        }
    }
}