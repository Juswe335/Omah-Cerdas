package com.example.omahcerdik

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Suhu : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_suhu)

        val lampButton: ImageView = findViewById(R.id.lmp_btn)
        lampButton.setOnClickListener {
            val intent = Intent(this, lamp::class.java)
            startActivity(intent)
        }

        val lockButton: ImageView = findViewById(R.id.lock_btn)
        lockButton.setOnClickListener {
            val intent = Intent(this, doorlock::class.java)
            startActivity(intent)
        }
    }
}